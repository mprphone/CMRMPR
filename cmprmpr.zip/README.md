
# AccounTech CRM – Versão Melhorada

Plataforma de gestão de avenças para gabinetes de contabilidade/serviços profissionais,
com análise de rentabilidade por cliente e por funcionário.

## Objetivos-chave
- Importar clientes e funcionários a partir do Supabase (outro software existente)
- Criar grupos de avenças
- Definir tarefas por cliente e respetiva carga horária
- Associar nº de funcionários e responsável
- Calcular rentabilidade da avença
- Calcular custo mensal da equipa
- Avaliar rentabilidade por funcionário
- Criar e gerir orçamentos para novos clientes

## Módulos Principais

### Clientes
- Dados gerais
- Grupo de avença
- Lista de tarefas
- Documentos associados
- Funcionários alocados
- Responsável
- Receita mensal
- Rentabilidade automática

### Funcionários
- Custo mensal (salário + encargos)
- Empresas sob responsabilidade
- Horas alocadas
- Rentabilidade individual

### Avenças
- Tipo de serviço
- Valor mensal
- Tarefas incluídas
- Horas estimadas
- Margem esperada

### Orçamentos
- Simulação de avença
- Estimativa de horas
- Cálculo automático de preço sugerido
- Conversão em cliente

## Lógica de Rentabilidade
Receita da avença  
– (Horas gastas x custo hora funcionário)  
= Margem real (€ e %)

## Tecnologias
- React + TypeScript
- Vite
- Supabase
- Estrutura preparada para BI futuro

## Próximos Passos
- Dashboard financeiro avançado
- Alertas de avenças deficitárias
- Integração com faturação
- Exportação para Excel/PDF
#   C M R M P R  
 